#include <stdio.h>

void
main ()
{
  printf ("Ruhi is the best , Tanvi loves Ruhi\n");

  return;
}
