#include <stdio.h>

void
main ()
{
  int x = 'a';
  printf ("the Ascii value is %d \n", x);

  char y = 'r';
  printf ("the Ascii value is %d \n", y);

  return;
}
